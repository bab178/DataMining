kmeans.py implemented in Python 3.6.0 using sklearn.cluster library

usage: install python 3.6.0
pip install numpy
pip install scipy
pip install sklearn

python ./kmeans.txt k inputX.txt
